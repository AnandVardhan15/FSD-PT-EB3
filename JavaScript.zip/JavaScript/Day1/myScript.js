function myFunction() {
    document.getElementById("demo").innerHTML = "Hello everyone Paragraph changed.";
  }
function myFunction1() {
    document.getElementById("demo").innerHTML = "Hello everyone ";
  }
function myFunction2() {
    document.getElementById("demo").innerHTML = "Hello everyone Paragraph its function 2";
  }
function myFunction3() {
    document.getElementById("demo").innerHTML = "Hello everyone Paragraph func3";
  }