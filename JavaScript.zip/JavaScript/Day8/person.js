//export const name = "Jesse";
//export const age = 40;



const name = "Jessy";
const age = 40;

export {name, age};

